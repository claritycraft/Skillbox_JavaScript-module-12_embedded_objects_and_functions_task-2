const promocodeObj = {
  promocode: "PROM50",
  gift: "Скидка 50%",
};

function getCookie() {
  return document.cookie.split("; ").reduce((acc, item) => {
    const [name, value] = item.split("=");
    acc[name] = value;
    return acc;
  }, {});
}

const cookie = getCookie();
const savedPromoCode = cookie.promocode;

if (savedPromoCode === promocodeObj.promocode) {
  document.getElementById("promocode").value = savedPromoCode;
  document.getElementById(
    "message"
  ).innerText = `${promocodeObj.gift} активирована!`;
  document.getElementById("apply-btn").disabled = true;
}

document.getElementById("apply-btn").addEventListener("click", function () {
  const userInput = document
    .getElementById("promocode")
    .value.trim()
    .toUpperCase();
  const messageElement = document.getElementById("message");

  if (userInput === promocodeObj.promocode) {
    document.cookie = `promocode=${userInput}; path=/;`;
    messageElement.innerText = `${promocodeObj.gift} активирован!`;
    messageElement.classList.remove("error");
    messageElement.classList.add("message");
    document.getElementById("apply-btn").disabled = true;
  } else {
    messageElement.innerText = "Неверный промокод.";
    messageElement.classList.remove("message");
    messageElement.classList.add("error");
  }
});
