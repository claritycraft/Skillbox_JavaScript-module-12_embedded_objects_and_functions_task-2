const inputEl = document.querySelector("#promocode");
const buttonEl = document.querySelector("#add");
const spanEl = document.querySelector("#check");

inputEl.addEventListener("input", () => {
  inputEl.setCustomValidity("");
  spanEl.textContent = "";
});

const validatePromo = () => {
  const promocodeArr = [
    {
      promocode: "PROM10",
      gift: "Скидка 10%",
    },
    {
      promocode: "PROM50",
      gift: "Скидка 50%",
    },
    {
      promocode: "GIFT",
      gift: "Подарок в корзине",
    },
  ];

  const promoCode = inputEl.value.trim();

  if (promoCode === "") {
    inputEl.setCustomValidity("Введите промокод");
    inputEl.reportValidity();
    return false;
  }

  // 3
  const foundPromo = promocodeArr.find((item) => item.promocode === promoCode);

  if (foundPromo) {
    spanEl.textContent = `Промокод применен: ${foundPromo.gift}`;
    inputEl.setCustomValidity("");
    spanEl.classList.remove("error");
    spanEl.classList.add("success");
    return true;
  } else {
    spanEl.textContent = "Неверный промокод";
    spanEl.classList.remove("success");
    spanEl.classList.add("error");
    return false;
  }
};

buttonEl.addEventListener("click", function (e) {
  e.preventDefault();
  validatePromo();
});
