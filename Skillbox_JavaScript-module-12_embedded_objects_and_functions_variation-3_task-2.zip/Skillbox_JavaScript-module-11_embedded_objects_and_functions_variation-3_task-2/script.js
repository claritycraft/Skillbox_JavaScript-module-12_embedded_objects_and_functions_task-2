document.addEventListener("DOMContentLoaded", () => {
  const inputEl = document.querySelector("#promocode");
  const buttonEl = document.querySelector("#add");
  const resetBtn = document.querySelector("#reset");
  const spanEl = document.querySelector("#check");

  function getCookie() {
    return document.cookie.split("; ").reduce((acc, item) => {
      const [name, ...rest] = item.split("=");
      const value = rest.join("=");
      acc[name] = value;
      return acc;
    }, {});
  }

  // Отображает ранее применённый промокод
  function showAppliedCode() {
    const cookie = getCookie();
    if (cookie.promoCode) {
      spanEl.textContent = `Вы уже применили промокод: ${cookie.promoCode}`;
      spanEl.className = "error";
    }
  }

  showAppliedCode();

  // Сбрасываем сообщения при вводе
  inputEl.addEventListener("input", () => {
    inputEl.setCustomValidity("");
    spanEl.textContent = "";
    spanEl.classList.remove("success", "error", "info", "success-cookies");
  });

  // Основная функция проверки и установки промокода
  function validatePromo() {
    const promocodeArr = [
      { promocode: "PROM10", gift: "Скидка 10%" },
      { promocode: "PROM50", gift: "Скидка 50%" },
      { promocode: "GIFT", gift: "Подарок в корзине" },
      { promocode: "FREE", gift: "Подарок" },
    ];

    const promoCode = inputEl.value.trim();
    const cookie = getCookie();

    // 1. Пустая строка
    if (promoCode === "") {
      inputEl.setCustomValidity("Введите промокод");
      inputEl.reportValidity();
      return false;
    }

    // Уже применён тот же промокод
    if (cookie.promoCode === promoCode) {
      spanEl.textContent = "Этот промокод уже был применён";
      spanEl.className = "error";
      return false;
    }

    // Поиск в списке доступных
    const foundPromo = promocodeArr.find(
      (item) => item.promocode === promoCode
    );

    if (foundPromo) {
      if (cookie.promoCode && cookie.promoCode !== promoCode) {
        spanEl.textContent = `Промокод обновлён: ${foundPromo.gift}`;
      } else {
        spanEl.textContent = `Промокод применен: ${foundPromo.gift}`;
      }

      spanEl.className = "success";
      inputEl.setCustomValidity("");

      // Устанавливаем/перезаписываем куки
      document.cookie = `promoCode=${promoCode}; path=/; max-age=31536000`;

      return true;
    }

    // Неверный промокод
    spanEl.textContent = "Неверный промокод";
    spanEl.className = "error";
    return false;
  }

  // Привязка «Применить»
  buttonEl.addEventListener("click", (e) => {
    e.preventDefault();
    validatePromo();
  });

  // Привязка «Сбросить»
  resetBtn.addEventListener("click", (e) => {
    e.preventDefault();
    document.cookie = "promoCode=; path=/; max-age=0";
    spanEl.textContent = "Промокод сброшен";
    spanEl.className = "info";
    inputEl.value = "";
  });
});
